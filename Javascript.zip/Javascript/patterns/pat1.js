for (let j = 5; j >= 1; j--) {

    for (let i = 1; i <= 6 - j; i++) {
        process.stdout.write(j + " ");
    }

    console.log();
}